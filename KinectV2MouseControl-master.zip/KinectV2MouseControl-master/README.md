#Kinect v2 Mouse Control

A mouse control application for Kinect v2, including a couple of options for various uses.

## Options

* Mouse Sensitivity
* Pause-To-Click Time Required
* Pause Movement Thresold
* Cursor Smoothing
* Grip Gesture / Pause To Click
* No clicks, move cursor only