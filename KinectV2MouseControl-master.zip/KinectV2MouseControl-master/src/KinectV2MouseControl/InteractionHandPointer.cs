﻿namespace KinectV2MouseControl
{
    internal class InteractionHandPointer
    {
    }
}